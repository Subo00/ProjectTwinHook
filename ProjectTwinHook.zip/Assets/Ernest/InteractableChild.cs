using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractableChild : Interactable
{
    protected override void OnUpdate(){
        CommonLogic();
    }
}
